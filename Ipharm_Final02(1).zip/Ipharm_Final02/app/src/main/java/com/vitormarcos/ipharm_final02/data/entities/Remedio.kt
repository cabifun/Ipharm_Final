package com.vitormarcos.ipharm_final02.data.entities

data class Remedio(
    val id: String = "",
    val nome: String = "",
    val descricao: String = "",
    val preco: Double = 0.0,

)

fun Remedio.toCartItem(quantidade: Int = 1): CartItem {
    return CartItem(
        id = this.id, // Usa o mesmo ID do remédio
        remedioNome = this.nome,
        remedioPreco = this.preco,
        quantidade = quantidade,
    )
}
fun getRemedioById(id: String?): Remedio? {
    val remedios = listOf(
        Remedio("1", "Paracetamol", "Para febre e dor.", 10.0),
        Remedio("2", "Ibuprofeno", "Anti-inflamatório.", 15.0),
        Remedio("3", "Amoxicilina", "Antibiótico.", 20.0),
        Remedio("4", "Omeprazol", "Para gastrite e refluxo.", 9.5),
        Remedio("5", "Loratadina", "Para rinite a alergias.", 9.9),
        Remedio("6", "Salbutamol", "Broncodilatador.", 6.4),
        Remedio("7", "Metformina", "Controle de diabetes tipo 2.", 5.5),
        Remedio("8", "Vick Vaporub", "Alívio da congestão nasal.", 10.9),
        Remedio("9", "Redoxon", "Suplemento de Vitamina C.", 18.0),
        Remedio("10", "Dorflex", "Para dores musculares.", 18.3)
    )
    return remedios.find { it.id == id }
}

