package com.vitormarcos.ipharm_final02.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.vitormarcos.ipharm_final02.data.entities.CartItem

class CartItemRepository {
    private val db = FirebaseFirestore.getInstance()
    private val cartItemsCollection = db.collection("cartItems")

    fun adicionarAoCarrinho(cartItem: CartItem, onResult: (Boolean) -> Unit) {
        cartItemsCollection.add(cartItem)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun listarCarrinho(onResult: (List<CartItem>) -> Unit) {
        cartItemsCollection.get()
            .addOnSuccessListener { result ->
                val items = result.map { document ->
                    document.toObject(CartItem::class.java).copy(id = document.id)
                }
                onResult(items)
            }
            .addOnFailureListener { onResult(emptyList()) }
    }


    fun removerDoCarrinho(id: String, onResult: (Boolean) -> Unit) {
        cartItemsCollection.document(id).delete()
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }
}
