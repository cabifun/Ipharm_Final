package com.vitormarcos.ipharm_final02.data.entities

data class CartItem(
    val id: String = "",
    val remedioNome: String = "",
    val remedioPreco: Double = 0.0,
    val quantidade: Int = 0
)

