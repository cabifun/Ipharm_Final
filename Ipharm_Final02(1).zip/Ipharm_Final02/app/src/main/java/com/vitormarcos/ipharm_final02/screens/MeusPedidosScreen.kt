package com.vitormarcos.ipharm_final02.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.vitormarcos.ipharm_final02.data.entities.Pedido
import com.vitormarcos.ipharm_final02.NotificationHelper
import com.vitormarcos.ipharm_final02.data.repository.PedidoRepository
import com.vitormarcos.ipharm_final02.viewModel.CartItemViewModel
import com.vitormarcos.ipharm_final02.viewModel.PedidoViewModel
import com.vitormarcos.ipharm_final02.viewModel.PedidoViewModelFactory

@Composable
fun MeusPedidosScreen(navController: NavHostController, pedidoViewModel: PedidoViewModel = viewModel()) {
    val pedidos by pedidoViewModel.pedidos.collectAsState(initial = emptyList())
    val context = LocalContext.current

    fun atualizarStatus(pedido: Pedido, novoStatus: String) {
        val pedidoAtualizado = pedido.copy(status = novoStatus)
        pedidoViewModel.atualizarPedido(pedidoAtualizado) // Atualiza no estado local

        val pedidoRepository = PedidoRepository()
        pedidoRepository.atualizarStatusPedido(pedido.id, novoStatus) { sucesso ->
            if (sucesso) {
                NotificationHelper.sendNotification(
                    context,
                    "Status do Pedido Atualizado",
                    "Seu pedido ${pedido.id} agora está com o status: $novoStatus"
                )
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Meus Pedidos",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(pedidos) { pedido ->
                PedidoItemView(pedido, onStatusChange = { novoStatus ->
                    atualizarStatus(pedido, novoStatus)
                })
            }
        }
    }
}


    @Composable
fun PedidoItemView(pedido: Pedido, onStatusChange: (String) -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Pedido ID: ${pedido.id}")
        Text(text = "Quantidade: ${pedido.quantidade}")
        Text(text = "Status: ${pedido.status}")

        // Botões para mudar o status do pedido
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onStatusChange("Em Processamento") }) {
                Text(text = "Processar")
            }
            Button(onClick = { onStatusChange("Finalizado") }) {
                Text(text = "Finalizar")
            }
        }
    }
}

