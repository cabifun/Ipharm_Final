package com.vitormarcos.ipharm_final02.viewModel

import androidx.lifecycle.ViewModel
import com.vitormarcos.ipharm_final02.data.entities.CartItem
import com.vitormarcos.ipharm_final02.data.entities.Pedido
import com.vitormarcos.ipharm_final02.data.repository.CartItemRepository
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class CartItemViewModel : ViewModel() {
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems

    private val cartRepository = CartItemRepository()
    private val pedidoRepository = FirebaseFirestore.getInstance().collection("pedidos")

    init {
        cartRepository.listarCarrinho { items ->
            _cartItems.value = items
        }
    }

    fun addToCart(cartItem: CartItem) {
        cartRepository.adicionarAoCarrinho(cartItem) { success ->
            if (success) {
                _cartItems.update { it + cartItem }
            }
        }
    }


    fun deleteCartItem(id: String) {
        cartRepository.removerDoCarrinho(id) { success ->
            if (success) {
                _cartItems.update { it.filterNot { it.id == id } }
            }
        }
    }

    fun adicionarPedido(pedido: Pedido, onResult: (Boolean) -> Unit) {
        pedidoRepository.add(pedido)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }
}
