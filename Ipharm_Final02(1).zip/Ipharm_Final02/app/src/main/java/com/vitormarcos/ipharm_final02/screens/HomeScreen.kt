package com.vitormarcos.ipharm_final02.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.vitormarcos.ipharm_final02.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        bottomBar = {
            BottomAppBar(
                containerColor = Color(0xFF00796B), // Cor do botão de emergência
                contentColor = Color.White
            ) {
                Button(
                    onClick = {
                        // Abre o discador com o número 190
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:192")
                        }
                        navController.context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text(
                        text = "EMERGÊNCIA",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { paddingValues ->
        Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .padding(paddingValues),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

                Image(
                    painter = painterResource(id = R.drawable.ipharm_logo),
                    contentDescription = "Logo da iPharm",
                    modifier = Modifier.height(200.dp)
                )

                // Botões de Login e Cadastro
                Column(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { navController.navigate("login") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Text(text = "Login", modifier = Modifier.padding(16.dp))
                    }

                    Button(
                        onClick = { navController.navigate("cadastro") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "Cadastrar", modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}
