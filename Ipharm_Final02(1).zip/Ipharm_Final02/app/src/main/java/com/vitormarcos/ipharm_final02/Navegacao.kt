package com.vitormarcos.ipharm_final02

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.vitormarcos.ipharm_final02.data.entities.getRemedioById
import com.vitormarcos.ipharm_final02.screens.*
import com.vitormarcos.ipharm_final02.viewModel.CartItemViewModel

@Composable
fun AppNavHost(navController: NavHostController) {
    val firebaseAuth = FirebaseAuth.getInstance()
    val currentUser = firebaseAuth.currentUser

    // Define a tela inicial com base na autenticação
    val startDestination = "home"

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // Tela inicial
        composable("home") {
            HomeScreen(navController) // Tela inicial com login e cadastro
        }

        // Tela de cadastro
        composable("cadastro") {
            CadastroScreen(navController)
        }

        // Tela de login
        composable("login") {
            LoginScreen(navController = navController)
        }

        // Tela do usuário após login
        composable("usuario_home/{nomeUsuario}") { backStackEntry ->
            val nomeUsuario = backStackEntry.arguments?.getString("nomeUsuario") ?: "Usuário"
            UsuarioHomeScreen(navController = navController, nomeUsuario = nomeUsuario)
        }

        // Tela do catálogo
        composable("catalogo") {
            CatalogoScreen(
                onNavigateToCompra = { remedio ->
                    navController.navigate("compra/${remedio.id}")
                }
            )
        }

        // Tela de compra
        composable("compra/{remedioId}") { backStackEntry ->
            val remedioId = backStackEntry.arguments?.getString("remedioId")
            val remedio = getRemedioById(remedioId)

            if (remedio != null) {
                val viewModel: CartItemViewModel = viewModel()

                CompraScreen(
                    remedio = remedio,
                    onAddToCart = { cartItem ->
                        viewModel.addToCart(cartItem)
                        navController.popBackStack()
                    },
                    onBack = { navController.popBackStack() }
                )
            } else {
                Text("Erro: Remédio não encontrado.")
            }
        }

        // Tela do carrinho
        composable("carrinho") { CartScreen(navController) }

        // Tela de pedidos
        composable("pedidos") { MeusPedidosScreen(navController) }
    }
}


// Função Preview fora do NavHost
@Composable
@Preview(showBackground = true)
fun PreviewApp() {
    val navController = rememberNavController()
    AppNavHost(navController) // A função AppNavHost agora é chamada dentro do contexto correto
}
