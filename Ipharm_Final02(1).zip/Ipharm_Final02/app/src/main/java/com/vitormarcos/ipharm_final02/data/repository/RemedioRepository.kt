package com.vitormarcos.ipharm_final02.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.vitormarcos.ipharm_final02.data.entities.Remedio

class RemedioRepository {
    private val db = FirebaseFirestore.getInstance()
    private val remediosCollection = db.collection("remedios")

    fun adicionarRemedio(remedio: Remedio, onResult: (Boolean) -> Unit) {
        remediosCollection.add(remedio)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun listarRemedios(onResult: (List<Remedio>) -> Unit) {
        remediosCollection.get()
            .addOnSuccessListener { result ->
                val remedios = result.map { document ->
                    document.toObject(Remedio::class.java).copy(id = document.id.toInt().toString())
                }
                onResult(remedios)
            }
            .addOnFailureListener { onResult(emptyList()) }
    }
}
