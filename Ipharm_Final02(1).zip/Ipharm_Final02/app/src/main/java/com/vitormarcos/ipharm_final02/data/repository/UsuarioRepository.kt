package com.vitormarcos.ipharm_final02.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.vitormarcos.ipharm_final02.data.entities.Usuario

class UsuarioRepository {
    private val db = FirebaseFirestore.getInstance()
    private val usuariosCollection = db.collection("usuarios")

    fun registrarUsuario(usuario: Usuario, onResult: (Boolean) -> Unit) {
        usuariosCollection.add(usuario)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun buscarUsuario(email: String, senha: String, onResult: (Usuario?) -> Unit) {
        usuariosCollection.whereEqualTo("email", email)
            .whereEqualTo("senha", senha)
            .get()
            .addOnSuccessListener { result ->
                val usuario = result.documents.firstOrNull()?.toObject(Usuario::class.java)
                onResult(usuario)
            }
            .addOnFailureListener { onResult(null) }
    }
    fun buscarUsuarioPorId(userId: String, onResult: (Usuario?) -> Unit) {
        usuariosCollection.document(userId).get()
            .addOnSuccessListener { document ->
                val usuario = document.toObject(Usuario::class.java)
                onResult(usuario)
            }
            .addOnFailureListener {
                onResult(null)
            }
    }

}
