package com.vitormarcos.ipharm_final02.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.vitormarcos.ipharm_final02.data.entities.Pedido

class PedidoRepository {
    private val db = FirebaseFirestore.getInstance()
    private val pedidosCollection = db.collection("pedidos")

    fun criarPedido(pedido: Pedido, onResult: (Boolean) -> Unit) {
        pedidosCollection.add(pedido)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }

    fun listarPedidos(onResult: (List<Pedido>) -> Unit) {
        pedidosCollection.get()
            .addOnSuccessListener { result ->
                val pedidos = result.map { document ->
                    document.toObject(Pedido::class.java).copy(id = document.id.toInt().toString())
                }
                onResult(pedidos)
            }
            .addOnFailureListener { onResult(emptyList()) }
    }

    fun atualizarStatusPedido(id: String, status: String, onResult: (Boolean) -> Unit) {
        pedidosCollection.document(id).update("status", status)
            .addOnSuccessListener { onResult(true) }
            .addOnFailureListener { onResult(false) }
    }
}
