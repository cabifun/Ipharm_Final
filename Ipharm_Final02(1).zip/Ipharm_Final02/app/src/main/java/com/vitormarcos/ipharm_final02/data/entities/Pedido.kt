package com.vitormarcos.ipharm_final02.data.entities

data class Pedido(
    val id: String = "",
    val cartItemId: String = " ",
    val quantidade: Int = 0,
    val status: String = ""
)
