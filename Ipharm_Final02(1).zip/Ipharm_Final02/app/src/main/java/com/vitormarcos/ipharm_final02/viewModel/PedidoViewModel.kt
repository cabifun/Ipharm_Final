package com.vitormarcos.ipharm_final02.viewModel

import androidx.lifecycle.ViewModel
import com.vitormarcos.ipharm_final02.data.entities.Pedido
import com.vitormarcos.ipharm_final02.data.repository.PedidoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow


class PedidoViewModel(private val pedidoRepository: PedidoRepository) : ViewModel() {
    private val _pedidos = MutableStateFlow<List<Pedido>>(emptyList())
    val pedidos: StateFlow<List<Pedido>> = _pedidos

    init {
        carregarPedidos()
    }

    private fun carregarPedidos() {
        pedidoRepository.listarPedidos { pedidos ->
            _pedidos.value = pedidos
        }
    }

    fun atualizarPedido(pedido: Pedido) {
        _pedidos.value = _pedidos.value.map {
            if (it.id == pedido.id) pedido else it
        }
    }

    fun atualizarStatusPedido(id: String, status: String, onResult: (Boolean) -> Unit) {
        pedidoRepository.atualizarStatusPedido(id, status, onResult)
    }
}
