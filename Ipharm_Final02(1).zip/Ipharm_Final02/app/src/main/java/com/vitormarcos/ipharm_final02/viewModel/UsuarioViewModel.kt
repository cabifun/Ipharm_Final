package com.vitormarcos.ipharm_final02.viewModel

import androidx.lifecycle.ViewModel
import com.vitormarcos.ipharm_final02.data.entities.Usuario
import com.vitormarcos.ipharm_final02.data.repository.UsuarioRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow


class UsuarioViewModel : ViewModel() {
    private val repository = UsuarioRepository()
    private val _usuarioLogado = MutableStateFlow<Usuario?>(null)
    val usuarioLogado: StateFlow<Usuario?> = _usuarioLogado

    fun login(email: String, senha: String) {
        repository.buscarUsuario(email, senha) { usuario ->
            _usuarioLogado.value = usuario
        }
    }

    fun registrar(usuario: Usuario, onComplete: (Boolean) -> Unit) {
        repository.registrarUsuario(usuario, onComplete)
    }
}
