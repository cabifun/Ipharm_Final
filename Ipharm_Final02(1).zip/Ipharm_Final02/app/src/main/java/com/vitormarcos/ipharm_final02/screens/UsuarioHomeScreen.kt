package com.vitormarcos.ipharm_final02.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth


@Composable
fun UsuarioHomeScreen(navController: NavController, nomeUsuario: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Bem-vindo, $nomeUsuario!", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        // Botão para acessar o catálogo
        Button(
            onClick = { navController.navigate("catalogo") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ir para o catálogo")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Botão para acessar o carrinho
        Button(
            onClick = { navController.navigate("carrinho") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ir para o carrinho")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Botão de deslogar
        Button(
            onClick = {
                FirebaseAuth.getInstance().signOut() // Desloga o usuário
                navController.navigate("home") {
                    popUpTo("home") { inclusive = true } // Remove o histórico de navegação anterior
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
            Text("Sair", color = MaterialTheme.colorScheme.onError)
        }
    }
            Button(
                onClick = { navController.navigate("pedidos") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Meus Pedidos")
            }

        // Botão de emergência no rodapé
        Button(
            onClick = {
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:192")
                }
                navController.context.startActivity(intent)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Emergência")
        }
    }



@Composable
fun BotaoNavegacao(navController: NavController, destino: String, textoBotao: String) {
    Button(
        onClick = {
            navController.navigate(destino)
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(text = textoBotao, color = Color.White)
    }
}
