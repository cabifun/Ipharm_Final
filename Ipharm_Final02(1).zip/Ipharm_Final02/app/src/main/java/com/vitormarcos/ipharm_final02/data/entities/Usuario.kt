package com.vitormarcos.ipharm_final02.data.entities

data class Usuario(
    val id: String = "",
    val nome: String = "",
    val email: String = "",
    val senha: String = "",
    val cpf: String = ""
)
