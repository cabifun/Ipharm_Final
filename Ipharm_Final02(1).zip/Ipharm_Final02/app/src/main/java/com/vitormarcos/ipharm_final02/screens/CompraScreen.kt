package com.vitormarcos.ipharm_final02.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vitormarcos.ipharm_final02.data.entities.Remedio
import com.vitormarcos.ipharm_final02.data.entities.CartItem
import com.vitormarcos.ipharm_final02.data.entities.toCartItem

@Composable
fun CompraScreen(
    remedio: Remedio,
    onAddToCart: (CartItem) -> Unit,
    onBack: () -> Unit
) {
    var quantidade by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {

        Column {
            Text(
                text = remedio.nome,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = remedio.descricao,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(16.dp))


            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Quantidade:")
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = { if (quantidade > 1) quantidade-- }) {
                    Text(text = "-", style = MaterialTheme.typography.headlineMedium)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = quantidade.toString())
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = { quantidade++ }) {
                    Text(text = "+", style = MaterialTheme.typography.headlineMedium)
                }
            }
        }

        // Botão para adicionar ao carrinho
        Button(onClick = {
            val cartItem = remedio.toCartItem(quantidade)
            onAddToCart(cartItem)
            onBack()
        }) {
            Text(text = "Adicionar ao Carrinho")
        }
    }
}
