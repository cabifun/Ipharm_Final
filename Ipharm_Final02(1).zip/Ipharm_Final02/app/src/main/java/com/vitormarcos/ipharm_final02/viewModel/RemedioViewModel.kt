package com.vitormarcos.ipharm_final02.viewModel

import com.vitormarcos.ipharm_final02.data.entities.Remedio
import androidx.lifecycle.ViewModel
import com.vitormarcos.ipharm_final02.data.repository.RemedioRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow


class RemedioViewModel : ViewModel() {
    private val repository = RemedioRepository()
    private val _remedios = MutableStateFlow<List<Remedio>>(emptyList())
    val remedios: StateFlow<List<Remedio>> = _remedios

    fun carregarRemedios() {
        repository.listarRemedios { remedios -> _remedios.value = remedios }
    }
}

