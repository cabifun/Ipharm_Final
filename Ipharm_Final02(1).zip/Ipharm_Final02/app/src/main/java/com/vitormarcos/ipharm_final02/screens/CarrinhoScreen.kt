package com.vitormarcos.ipharm_final02.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.vitormarcos.ipharm_final02.data.entities.Pedido
import com.vitormarcos.ipharm_final02.viewModel.CartItemViewModel
import com.vitormarcos.ipharm_final02.NotificationHelper
import com.vitormarcos.ipharm_final02.data.entities.CartItem


@Composable
fun CartScreen(navController: NavHostController, cartItemViewModel: CartItemViewModel = viewModel()) {
    val context = LocalContext.current
    val cartItems by cartItemViewModel.cartItems.collectAsState(initial = emptyList())

    val total = cartItems.sumOf { it.remedioPreco * it.quantidade }

    fun finalizarPedido() {
        if (cartItems.isNotEmpty()) {
            cartItems.forEach { cartItem ->
                val pedido = Pedido(
                    id = cartItem.id + System.currentTimeMillis().toString(), // ID único
                    cartItemId = cartItem.id,
                    quantidade = cartItem.quantidade,
                    status = "Aguardando Pagamento"
                )

                // Adiciona o pedido ao Firestore
                cartItemViewModel.adicionarPedido(pedido) { success ->
                    if (success) {
                        NotificationHelper.sendNotification(
                            context,
                            "Pedido em Processamento",
                            "Seu pedido foi registrado com status: Aguardando Pagamento"
                        )
                        // Navegar para a tela de Meus Pedidos
                        navController.navigate("pedidos") {
                            popUpTo("carrinho") { inclusive = true } // Remove a tela do carrinho da pilha
                        }
                    }
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Meu Carrinho",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(16.dp)
        )

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(cartItems) { cartItem ->
                CartItemView(cartItem, cartItemViewModel)
            }
        }

        Text(
            text = "Total: R$ ${"%.2f".format(total)}",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(16.dp)
        )

        Button(
            onClick = { finalizarPedido() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(text = "Finalizar Pedido")
        }
    }
}


@Composable
fun CartItemView(cartItem: CartItem, cartItemViewModel: CartItemViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = cartItem.remedioNome,
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                text = "Preço: R$ ${"%.2f".format(cartItem.remedioPreco)}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Quantidade: ${cartItem.quantidade}",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Button(onClick = { cartItemViewModel.deleteCartItem(cartItem.id) }) {
            Text(text = "Remover")
        }
    }
}

