package com.vitormarcos.ipharm_final02.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import com.vitormarcos.ipharm_final02.data.entities.Remedio
import com.vitormarcos.ipharm_final02.viewModel.CartItemViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun CatalogoScreen(
    cartItemViewModel: CartItemViewModel = viewModel(),
    onNavigateToCompra: (Remedio) -> Unit
) {
    val remedios = listOf(
        Remedio("1", "Paracetamol", "Para dor e febre.", 15.0),
        Remedio("2", "Ibuprofeno", "Anti-inflamatório.", 15.0),
        Remedio("3", "Amoxicilina", "Antibiótico.", 23.0),
        Remedio("4", "Omeprazol", "Para gastrite e refluxo.", 9.5),
        Remedio("5", "Loratadina", "Para rinite a alergias.", 9.9),
        Remedio("6", "Salbutamol", "Broncodilatador.", 6.4),
        Remedio("7", "Metformina", "Controle de diabetes tipo 2.", 5.5),
        Remedio("8", "Vick Vaporub", "Alívio da congestão nasal.", 10.9),
        Remedio("9", "Redoxon", "Suplemento de Vitamina C.", 18.0),
        Remedio("10", "Dorflex", "Para dores musculares.", 18.3)
    )

    LazyColumn(modifier = Modifier.padding(16.dp)) {
        items(remedios) { remedio ->
            CatalogItem(remedio, onNavigateToCompra)
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun CatalogItem(
    remedio: Remedio,
    onNavigateToCompra: (Remedio) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.weight(1f)
        ) {
            Text(text = remedio.nome, fontWeight = FontWeight.Bold)
            Text(text = remedio.descricao, color = Color.Gray)
            Text(text = "R$ ${"%.2f".format(remedio.preco)}", color = Color.Black)
        }

        IconButton(
            onClick = { onNavigateToCompra(remedio) }
        ) {
            Icon(
                imageVector = Icons.Filled.ShoppingCart,
                contentDescription = "Comprar",
                tint = Color.Black
            )
        }
    }
}


